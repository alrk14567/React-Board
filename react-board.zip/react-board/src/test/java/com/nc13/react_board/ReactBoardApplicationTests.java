package com.nc13.react_board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
